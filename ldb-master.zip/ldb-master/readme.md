The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
